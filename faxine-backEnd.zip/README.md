php artisan migrate:fresh --seed

Header => { Authorization : Bearer *token* }
